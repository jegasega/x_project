require 'aws-sdk-resources'
