#ifndef Py_DESCROBJECT_H
#define Py_DESCROBJECT_H

#include "cpyext_descrobject.h"

#endif
